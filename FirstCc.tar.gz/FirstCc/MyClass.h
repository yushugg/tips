/*
 * MyClass.h
 *
 *  Created on: 2013年8月15日
 *      Author: yushu
 */

#ifndef MYCLASS_H_
#define MYCLASS_H_

#include <iostream>

namespace MyName {

class MyClass {
public:
	MyClass(const char* str = "");
	MyClass(const MyClass &m);
	virtual ~MyClass();
	MyClass operator-() const;
	friend MyClass operator+(const MyClass &m1, const MyClass &m2);
	friend std::ostream& operator<<(std::ostream &out, const MyClass &m);
	friend std::istream& operator>>(std::istream &in, MyClass &m);
private:
	char* myString;
};

} /* namespace MyName */
#endif /* MYCLASS_H_ */
