/*
 * MyClass.h
 *
 *  Created on: 2013年8月15日
 *      Author: yushu
 */

#ifndef MYCLASS_H_
#define MYCLASS_H_

namespace MyName {

class MyClass {
public:
	MyClass();
	virtual ~MyClass();
};

} /* namespace MyName */
#endif /* MYCLASS_H_ */
