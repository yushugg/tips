#include <iostream>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include "MyClass.h"

// Define macros
#define TEST_MYCLASS
//#define TEST_HELLO_WORLD
//#define TEST_ADD_CPP
//#define TEST_DATA_TYPE_SIZE
//#define TEST_OVERFLOW
//#define TEST_FLOAT_PRECISION
//#define TEST_ENUM
//#define TEST_STRUCT
//#define TEST_RAND
//#define TEST_STRING

#ifdef TEST_ADD_CPP
//extern int sNum;
extern int add(int a, int b);
#endif

int main(int argc, char* argv[])
{
#ifdef TEST_MYCLASS
	MyName::MyClass my1("I O U");
	MyName::MyClass my2("Cpp is so fine!");
	//MyName::MyClass my1, my2;
	//std::cin >> my1 >> my2;
	MyName::MyClass my3(my1);
	MyName::MyClass my4 = my2;// Using copy constructor, not operator=
	my4 = my1;// Using operator=

	std::cout << my1 << std::endl;
	std::cout << -my1 << std::endl;
	std::cout << my2 << std::endl;
	std::cout << -(my1+my2) << std::endl;
#endif

#ifdef TEST_HELLO_WORLD
	std::cout << "Hello World!" << std::endl;
#endif

#ifdef TEST_ADD_CPP
	std::cout << add(2, 3) << std::endl;
#endif

#ifdef TEST_DATA_TYPE_SIZE
	std::cout << "bool:\t\t" << sizeof(bool) << " bytes" << std::endl;
	std::cout << "char:\t\t" << sizeof(char) << " bytes" << std::endl;
	std::cout << "wchar_t:\t\t" << sizeof(wchar_t) << " bytes" << std::endl;
	std::cout << "short:\t\t" << sizeof(short) << " bytes" << std::endl;
	std::cout << "int:\t\t" << sizeof(int) << " bytes" << std::endl;
	std::cout << "long:\t\t" << sizeof(long) << " bytes" << std::endl;
	std::cout << "float:\t\t" << sizeof(float) << " bytes" << std::endl;
	std::cout << "double:\t\t" << sizeof(double) << " bytes" << std::endl;
	std::cout << "long double:\t\t" << sizeof(long double) << " bytes" << std::endl;
#endif

	// Test overflow
#ifdef TEST_OVERFLOW
	unsigned short x = 65535;
	std::cout << "x: " << x << std::endl;
	x = x + 1;
	std::cout << "x+1:" << x << std::endl;

	short y = 32767;
	std::cout << "y: " << y << std::endl;
	y = y + 1;
	std::cout << "y+1:" << y << std::endl;

	short z = 32768;
	std::cout << "z: " << z << std::endl;
	z = z + 1;
	std::cout << "z+1:" << z << std::endl;
#endif

#ifdef TEST_FLOAT_PRECISION
	const float f = 1.123456789f;
	const double d = 1.123456789;
	std::cout << "f: " << f << std::endl;
	std::cout << "d: " << d << std::endl;
	std::cout << "f after casting: " << static_cast<int>(f) << std::endl;
#endif

#ifdef TEST_ENUM
	enum Color{
		RED = 1,
		GREEN,
		BLUE
	};
	Color color = GREEN;
	switch(color)
	{
	case RED:
		std::cout << "red" << std::endl;
		break;
	case GREEN:
		std::cout << "green" << std::endl;
		break;
	case BLUE:
		std::cout << "blue" << std::endl;
		break;
	}
#endif

#ifdef TEST_STRUCT
	struct Contacts{
		const char* email;
		const char* phoneNumber;
	};
	struct Person{
		Contacts contact;
		int height;
		int weight;
	};

	Person p1;
	p1.contact.email = "p1@gmail.com";
	p1.contact.phoneNumber = "13901001573";
	p1.height = 175;
	p1.weight = 75;

	std::cout << "p1: \n" << p1.contact.email << std::endl <<
			p1.contact.phoneNumber << std::endl <<
			p1.height << std::endl <<
			p1.weight << std::endl;
#endif

#ifdef TEST_RAND
	std::cout << time(0) << std::endl;
	srand(time(0));
	for (int i = 0; i < 10; ++i)
	{
		std::cout << "Random number is: " << rand()%(10-1)+1 << std::endl;
	}
#endif

#ifdef TEST_STRING
	std::string strTest = "Halo";
	getline(std::cin, strTest);
	std::cout << strTest.length() << std::endl;
	int x;
	std::cout << "Input x: ";
	std::cin >> x;
	assert(x > 0);
	std::cout << "x is: " << x << std::endl;
#endif

	return 0;
}
