#include <iostream>

int add(int a, int b)
{
	std::cout << "Hello, this is Add.cpp" << std::endl;

	return a + b;
}
