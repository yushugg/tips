/*
 * MyClass.cpp
 *
 *  Created on: 2013年8月15日
 *      Author: yushu
 */

#include <iostream>
#include "MyClass.h"

namespace MyName {

MyClass::MyClass() {
	std::cout<<"Construct MyClass"<<std::endl;
}

MyClass::~MyClass() {
	std::cout<<"MyClass destroyed"<<std::endl;
}

} /* namespace MyName */
