/*
 * MyClass.cpp
 *
 *  Created on: 2013年8月15日
 *      Author: yushu
 */

#include <iostream>
#include <cstring>
#include "MyClass.h"

namespace MyName {

MyClass::MyClass(const char* str) {
	std::cout<<"Construct MyClass"<<std::endl;

	// Copy str to myString
	const size_t length = strlen(str);
	myString = new char[length+1];
	strncpy(myString, str, length);
	myString[length] = '\0';
}

MyClass::MyClass(const MyClass &m)
{
	std::cout << "Copy Constructor being used" << std::endl;

	const size_t length = strlen(m.myString);
	myString = new char[length+1];
	strncpy(myString, m.myString, length);
	myString[length] = '\0';
}

MyClass::~MyClass() {
	std::cout<<"MyClass destroyed"<<std::endl;

	delete[] myString;
}

MyClass MyClass::operator-() const
{
	return MyClass("~")+*this;
}

MyClass operator+(const MyClass &m1, const MyClass &m2)
{
	const size_t m1Len = strlen(m1.myString);
	const size_t m2Len = strlen(m2.myString);
	const size_t m3Len = m1Len + m2Len;

	char* m3Str = new char[m3Len + 1];
	for (size_t i = 0; i != m1Len; ++i)
	{
		m3Str[i] = m1.myString[i];
	}

	for (size_t i = m1Len; i != m3Len+1; ++i)
	{
		m3Str[i] = m2.myString[i-m1Len];
	}
	MyClass temp(m3Str);
	delete[] m3Str;

	return temp;
}

std::ostream& operator<<(std::ostream &out, const MyClass &m)
{
	out << "MyString is: " << m.myString;

	return out;
}

std::istream& operator>>(std::istream &in, MyClass &m)
{
	std::cout << "Input a string: ";
	in >> m.myString;
	return in;
}

} /* namespace MyName */
